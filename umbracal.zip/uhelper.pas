unit UHelper;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Math;

const
  DEG_TO_RAD = Pi / 180.0;
  RAD_TO_DEG = 180.0 / Pi;
  TWO_PI     = 2.0 * Pi;
  J2000      = 2451545.0;

type
  TAngleStyle = (asSigned, asLatitude, asLongitude, asUnsigned);

function Normalize360(angle: Double): Double;
function Normalize180(angle: Double): Double;
function Normalize2Pi(angle: Double): Double;
function NormalizePi(rad: Double): Double;
function AngularDelta(a, b: Double): Double;
function NormalizeFraction(x: Double): Double;
function HorizonDip(elevationMeters: Double): Double;
function RefractAltitude(alt: Double): Double;
function NormalizeHours(h: Double): Double;
function JDToISO(AJD: Double): string;
function JDToStrFull(AJD: Double): string;
function DegToDMS(const ADegrees: Double; const AStyle: TAngleStyle = asSigned;
  const ADecimals: Integer = 0; const ASeconds: Boolean = False): string;

implementation

// [0, 360)
function Normalize360(Angle: Double): Double;
begin
  Result := Angle - 360.0 * Floor(Angle / 360.0);
end;

// (-180, 180]
function Normalize180(angle: Double): Double;
begin
  angle := fmod(angle, 360.0);
  if angle <= -180.0 then
    angle := angle + 360.0
  else if angle > 180.0 then
    angle := angle - 360.0;
  Result := angle;
end;

// [0, 2Pi)
function Normalize2Pi(Angle: Double): Double;
begin
  Result := Angle - (2.0 * Pi) * Floor(Angle / (2.0 * Pi));
end;

// (-Pi, Pi]
function NormalizePi(rad: Double): Double;
begin
  rad := fmod(rad, TWO_PI);
  if rad <= -Pi then
    rad := rad + TWO_PI
  else if rad > Pi then
    rad := rad - TWO_PI;
  Result := rad;
end;

// How far do I rotate from a to b?
function AngularDelta(a, b: Double): Double;
begin
  Result := Normalize180(b - a);
end;

function NormalizeFraction(x: Double): Double;
begin
  Result := x - Floor(x);
  if Result < 0 then Result := Result + 1;
end;

function HorizonDip(elevationMeters: Double): Double;
begin
  Result := -0.0293 * Sqrt(elevationMeters);
end;

function RefractAltitude(alt: Double): Double;
begin
  if (alt > -1) and (alt < 90) then
    Result := alt + (1.02 / Tan((alt + 10.3 / (alt + 5.11)) * DEG_TO_RAD)) / 60
  else
    Result := alt;
end;

function NormalizeHours(H: Double): Double;
begin
  Result := H - 24.0 * Floor(H / 24.0);
end;

function JDToISO(AJD: Double): string;
var
  LJD:   Double;
  LZ, LA, LB, LC, LD, LE, LYear, LMonth: Integer;
  LAlpha, LF: Double;
  LDay:  Integer;
begin
  LJD    := AJD + 0.5;
  LZ     := Trunc(LJD);
  LF     := LJD - LZ;

  LAlpha := Trunc((LZ - 1867216.25) / 36524.25);
  LA     := LZ + 1 + Trunc(LAlpha) - Trunc(LAlpha / 4);
  LB     := LA + 1524;
  LC     := Floor((LB - 122.1) / 365.25);
  LD     := Floor(365.25 * LC);
  LE     := Trunc((LB - LD) / 30.6001);

  LDay   := LB - LD - Trunc(30.6001 * LE);

  if LE < 14 then LMonth := LE - 1 else LMonth := LE - 13;
  if LMonth > 2 then LYear := LC - 4716 else LYear := LC - 4715;

  Result := Format('%d-%2.2d-%2.2d', [LYear, LMonth, LDay]);
end;

function JDToStrFull(AJD: Double): string;
begin
  // e.g. "2025-06-21 (JD 2460847.5)"
  //Result := JDToISO(AJD) + Format(' (JD %.1f)', [AJD]);
  Result := Format('%.7f', [AJD]);
end;

function DegToDMS(const ADegrees: Double; const AStyle: TAngleStyle;
  const ADecimals: Integer; const ASeconds: Boolean): string;
var
  LNeg:  Boolean;
  LTicks, LScale: Int64;
  LD, LM: Integer;
  LS:     Double;
  LPre, LSuf: string;
begin
  LNeg := ADegrees < 0;

  { Round once, in units of the smallest displayed digit, so the carry
    propagates instead of surfacing as 60.00". }
  LScale := Round(IntPower(10, ADecimals));
  LTicks := Round(Abs(ADegrees) * 3600.0 * LScale);

  LS := (LTicks mod (60 * LScale)) / LScale;
  LTicks := LTicks div (60 * LScale);
  LM := LTicks mod 60;
  LTicks := LTicks div 60;
  LD := LTicks;

  LPre := '';
  LSuf := '';
  case AStyle of
    asSigned:    if LNeg then LPre := '-';
    asLatitude:  if LNeg then LSuf := ' S' else LSuf := ' N';
    asLongitude: if LNeg then LSuf := ' W' else LSuf := ' E';
    asUnsigned:  ;
  end;

  if ASeconds Then
    Result := Format('%s%d° %.2d'' %.*f"%s',
                     [LPre, LD, LM, ADecimals, LS, LSuf])
  else
     Result := Format('%s%d° %.2d''', [LPre, LD, LM]);

end;

end.

